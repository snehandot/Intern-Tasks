import ollama
from rich.console import Console
console=Console()
#receive=input("Receiver email")
ollama.pull("phi3")
print("done")
inp=input("What should i email about ->  ")
lis=[]
stream = ollama.chat(
	model="tinyllama",
	messages = [{
	"role":"user",
	'content': "You are a email composing agent for me Sree Snehan, proper compose an email for the given content with Subject , Main Content , Regards Sree Snehan to send email"+inp,
	}],
	stream=True
)
for chunk in stream:
	
	lis.append(chunk['message']['content'])
string=""
for x in lis:
	string=string+str(x)+" "
print(string)
	
import smtplib

email="22d148@psgitech.ac.in"
receive="snehandot@gmail.com"

subject= ""
message= string

text = f"Subject: {subject}\n\n{message}"
server =smtplib.SMTP("smtp.gmail.com",587)
server.starttls()

server.login(email,"uemtqrayscmszceu")

server.sendmail(email,receive,text)

print("sent")


import xmlrpc.client

url = "https://niodigital-niofusion-ai-trial-staging-02052024-12979131.dev.odoo.com"
db = "niodigital-niofusion-ai-trial-staging-02052024-12979131"
username = "admin"
password = "Nio@123"

common = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common")
models = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/object")
partner_id1="HI1"
partner_id2="HI2"

uid = common.authenticate(db, username, password, {})
meeting_data = {
    'name': 'Automated Meeting',
    'start': '2024-06-15 09:00:00',
    'stop': '2024-06-15 10:00:00',
    'duration': 1.0,
    'user_id': uid,  # User creating the meeting
    'partner_ids': [(6, 0, [partner_id1, partner_id2])],  # List of participant partner IDs
}
meeting_id = models.execute_kw(db, uid, password,
    'calendar.event', 'create', [meeting_data])

print(f"Meeting created with ID: {meeting_id}")

from autogen import AssistantAgent, UserProxyAgent

config_list = [
    {
        "model": "llama2",
        "base_url": "http://localhost:11434/v1",
        "api_key": "ollama",
    }
]

# Create UserProxyAgent instance
user_proxy_agent = UserProxyAgent(
    name="user",
    human_input_mode="ALWAYS",  # Set to "ALWAYS" to allow user input
    code_execution_config={"use_docker": False},
)

# Create AssistantAgent instance
assistant = AssistantAgent(
    name="assistant",
    llm_config={"config_list": config_list},
    system_message="You are a helpful assistant.",
)

# Start the conversation by sending code from UserProxyAgent to AssistantAgent
code = """import numpy as np

# List of numbers
numbers = [2, 4, 6, 8, 10]

# Convert the list to a NumPy array
numbers_array = np.array(numbers)

# Calculate the mean and standard deviation using NumPy functions
mean = np.mean(numbers_array)
std_dev = np.std(numbers_array)

# Print the results
print("List of numbers:", numbers)
print("Mean:", mean)
print("Standard Deviation:", std_dev)
"""
assistant_response = user_proxy_agent.initiate_chat(assistant, message="give execution output, pre-required modules that should be install before execution and error if there is any the code:  "+code)
print(f"{assistant.name}: {assistant_response}")

# Loop to handle conversation
while True:
    user_input = input(f"{user_proxy_agent.name.capitalize()}: ").strip()

    # Exit loop if user enters 'exit'
    if user_input.lower() == 'exit':
        break

    # Continue the conversation by sending user input to AssistantAgent
    assistant_response = user_proxy_agent.continue_chat(user_input)
    print(f"{assistant.name}: {assistant_response}")
